<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Devops HTML Website Template</title>
<!--
Upper Template
http://www.templatemo.com/tm-497-upper
-->
    <!-- load stylesheets -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400">  
    <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.5.0/css/font-awesome.min.css">                
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css">                                      
    <!-- Bootstrap style -->
    <link rel="stylesheet" href="css/hero-slider-style.css">                              
    <!-- Hero slider style (https://codyhouse.co/gem/hero-slider/) -->
    <link rel="stylesheet" href="css/magnific-popup.css">                                 
    <!-- Magnific popup style (http://dimsemenov.com/plugins/magnific-popup/) -->
    <link rel="stylesheet" href="css/templatemo-style.css">                                   
    <!-- Templatemo style -->

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          <![endif]-->
</head>

    <body>
        
        <!-- Content -->
        <div class="cd-hero">

            <!-- Navigation -->        
            <div class="cd-slider-nav">
                <nav class="navbar">
                    <div class="tm-navbar-bg">
                        
                        <a class="navbar-brand text-uppercase" href="#"><i class="fa fa-flash tm-brand-icon"></i>COLOR & SHINE</a>

                        <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#tmNavbar">
                            &#9776;
                        </button>
                        <div class="collapse navbar-toggleable-md text-xs-center text-uppercase tm-navbar" id="tmNavbar">
                            <ul class="nav navbar-nav">
                                <li class="nav-item active selected">
                                    <a class="nav-link" href="#0" data-no="1">Home <span class="sr-only">(current)</span></a>
                                </li>                                
                                <li class="nav-item">
                                    <a class="nav-link" href="#0" data-no="2">Skin Care</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#0" data-no="3">Hair Care</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#0" data-no="4">Beauty Care</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#0" data-no="5">Tips</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#0" data-no="6">Contact</a>
                                </li>
                            </ul>
                        </div>                        
                    </div>

                </nav>
            </div> 

            <ul class="cd-hero-slider">

                <!-- Page 1 Home -->
                <li class="selected">
                    <div class="cd-full-width">
                        <div class="container-fluid js-tm-page-content tm-page-pad" data-page-no="1">
                            <div class="row">
                                    <div class="tm-3-col-container">                                        
                                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm-3-col-textbox">
                                                <div class="text-xs-left tm-textbox tm-textbox-padding tm-bg-white-translucent tm-3-col-textbox-inner">
                                                    <i class="fa fa-4x fa-pagelines tm-home-fa"></i>
                                                    <h2 class="tm-text-title">Hello Guest</h2>                                           
                                                    <p class="tm-text">Color & shine is a website detailing the different skincare, hair care and beauty care that is used by various individuals on a daily basis.It is complete clean and green beauty products.</p>
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm-3-col-textbox">
                                                <div class="text-xs-left tm-textbox tm-textbox-padding tm-bg-white-translucent tm-3-col-textbox-inner">
                                                    <i class="fa fa-4x fa-bicycle tm-home-fa"></i>
                                                    <h2 class="tm-text-title">Welcome!</h2>
                                                    <p class="tm-text">There are 3 different gallaries in this website. You can select any page to view about skincare,beautycare, healthcare products which provides a solid reading material to understand. Good luck!</p>
                                                </div>          
                                            </div>
                                            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm-3-col-textbox">
                                                <div class="text-xs-left tm-textbox tm-textbox-padding tm-bg-white-translucent tm-3-col-textbox-inner">
                                                    <i class="fa fa-4x fa-plane tm-home-fa"></i>
                                                    <h2 class="tm-text-title">Stay relaxed</h2>
                                                    <p class="tm-text">You can easily find the skincare routines along with ingeredients and methods to follow.self care starts with skin care.Happiness is a habit, so is your skin care.Let your confidence shine pretty girl</p>
                                                </div>          
                                            </div>                                        
                                    </div>
                            </div>
                        </div>
                    </div>
                </li>
                
                <!-- Page 2 Gallery One -->
                <li>                    
                    <div class="cd-full-width">
                        <div class="container-fluid js-tm-page-content" data-page-no="2" data-page-type="gallery">
                            <div class="tm-img-gallery-container">
                                <div class="tm-img-gallery gallery-one">
                                <!-- Gallery One pop up connected with JS code below -->                                    
                                    <div class="tm-img-gallery-info-container">                                    
                                        <h2 class="tm-text-title tm-gallery-title tm-white"><span class="tm-white">Skin Care</span></h2>
                                        <p class="tm-text">Good skin care is important at any age. The skin has strong collagen and elastin production in the first few decades of life, but it decreases. A good skincare routine helps regenerate skin cell production to keep the skin looking and feeling its best throughout your life.
                                        </p>
                                    </div>
                                    <div class="grid-item">
                                    <figure class="effect-ruby">
                                            
                                            
                                            <img src="https://dqt8gd4elnkw6.cloudfront.net/image/7-Ways-To-Use-Turmeric-for-Glowing-Skin-Blog-Cover.jpg" alt="Image" class="img-fluid tm-img">
            
                                            
                                            <figcaption>
                                                <h2 class="tm-figure-title">Turmeric <span>powder</span></h2>
                                                <p class="tm-figure-description"> .Applying Natural turmeric face masks and Using Natural skincare products that contain Turmeric.Turmeric can be used for skin whitening and glowing skin as well</p>
                                                <a href="img/tm-img-01.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://stylecaster.com/wp-content/uploads/2015/04/at-home-remedies.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">potato <span>pack</span></h2>
                                                <p class="tm-figure-description">Grate half a potato, and mix it with half a teaspoon of turmeric. Apply the paste to your face and neck, and let it sit for 15 minutes before washing it off.According to archaeological archives,used for skin burn</p>
                                                <a href="img/tm-img-02.jpg">View more</a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq4jFznvGDX2d8OJ-WqFz0klMCwVWlKVN1ReIo2jsfJzCtgryAYEqEYJkeBBb4aoIYmes&usqp=CAU" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Honey<span>pack</span></h2>
                                                <p class="tm-figure-description">To use honey to treat acne and oily skin, spread a thin layer, preferably raw, onto your face; let it dry for about 10 minutes, and rinse thoroughly with warm water</p>
                                                <a href="img/tm-img-03.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://thestripe.com/wp-content/uploads/2018/07/egg-beauty-benefits-1-e1532559979659.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">egg<span>paack</span></h2>
                                                <p class="tm-figure-description">First, separate the egg white and beat it with a fork or whisk until it's creamy. You can also add 1 tablespoon of lemon juice to help exfoliate your skin.it helps with oily skin and can also be used as night skincare</p>
                                                <a href="img/tm-img-04.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>                                                                          
                                </div>                                 
                            </div>
                        </div>                                                    
                    </div>                    
                </li>

                <!-- Page 3 Gallery Two -->
                <li>                    
                    <div class="cd-full-width">
                        <div class="container-fluid js-tm-page-content" data-page-no="3" data-page-type="gallery">
                            <div class="tm-img-gallery-container tm-img-gallery-container-2">
                                <div class="tm-img-gallery gallery-two">
                                <!-- Gallery Two pop up connected with JS code below -->
                                    
                                    <div class="tm-img-gallery-info-container">                                    
                                        <h2 class="tm-text-title tm-gallery-title"><span class="tm-white">Hair care</span></h2>
                                        <p class="tm-text"><span class="tm-white">Hair care is important for not only our appearance, but also for our overall hygiene. Having healthy hair allows us to look our best and ensure our hair and scalp is healthy. It is important to visit a reputable salon and utilize quality hair care products to ensure your hair is as healthy as possible.</span>
                                        </p>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://hips.hearstapps.com/hmg-prod/images/hairtreatments-1588019703.png?resize=1200:*" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Lemon<span>juice</span></h2>
                                                <p class="tm-figure-description">Lemons  many nutrients that strengthen the hair follicles and encourage new hair growth. Naturally acidic,Add a tablespoon of warm olive oil, half a tablespoon of warm castor oil, and 3-4 drops of organic lemon juice. Massage the oil mixture into the scalp, and leave it in for 10-15 minutes or even overnight</p>
                                                <a href="img/tm-img-05.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShN_Bx9zGzLeHMDKLLcFm19c6n9f8S7dETDRmcc9RJ2aX76jvc4_OUgjF69AwkytjqFik&usqp=CAU" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Onion<span>Juice</span></h2>
                                                <p class="tm-figure-description">The sulfur from onions may also help promote collagen production.Peel and chop three to four onions into small pieces.Extract the juice by squeezing or blending them.Apply the juice to your scalp using a cotton pad.Massage it into the scalp, let it sit for an hour, and then rinse</p>
                                                <a href="img/tm-img-06.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://www.fashionlady.in/wp-content/uploads/2016/05/Best-Hair-Oil-For-Natural-Hair-Growth.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Coconut<span>milk/oil</span></h2>
                                                <p class="tm-figure-description">The vitamins and essential fatty acids naturally found in coconut oil .Warm the coconut oil.Apply the coconut oil to the dry hair.Leave on for 30 minutes—or overnight.</p>
                                                <a href="img/tm-img-07.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://www.healthshots.com/wp-content/uploads/2020/07/aloe-vera-gel.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">aloevera<span>usage</span></h2>
                                                <p class="tm-figure-description">aloevera boosts the hair growth.
cut a leaf from a live aloe vera plant.using a spoon, collect the gel rub the gel or mixture directly into the scalp
repeat this process 2-3 times a week, as needed.</p>
                                                <a href="img/tm-img-08.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://cdn.shopify.com/s/files/1/0488/5204/1891/products/612wINmimoL._SL1064.jpg?v=1631736045" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Hibiscus<span>Leaves</span></h2>
                                                <p class="tm-figure-description">Hibiscus aids hair growth from dormant hair follicles helping cover bald patches and also combats dryness and dandruff. Take two hibiscus flowers and at least 7-8 young hibiscus leaves. Add a teaspoon of coconut oil and grind into a paste.</p>
                                                <a href="img/tm-img-09.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://cdn.shopaccino.com/refresh/articles/amla-hair-oil-blog-132916_l.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Amla<span>powder</span></h2>
                                                <p class="tm-figure-description">,Amla can help balance a flaky scalp etc.One can pick a fresh amla and grind it into a paste. Squeeze the paste to extract the juice. You can prepare a hair tonic by adding hand-pressed lemon juice to the amla juice and applying it directly to the scalp.</p>
                                                <a href="img/tm-img-10.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>  
                                </div>                                 
                            </div>
                        </div>                      
                    </div>
                </li>

                <!-- Page 4 Gallery Three -->
                <li>
                    <div class="cd-full-width">
                        <div class="container-fluid js-tm-page-content" data-page-no="4" data-page-type="gallery">                        
                            <div class="tm-img-gallery-container tm-img-gallery-container-3">
                                <div class="tm-img-gallery gallery-three">
                                <!-- Gallery Two pop up connected with JS code below -->
                                    
                                    <div class="tm-img-gallery-info-container">                                    
                                        <h2 class="tm-text-title tm-gallery-title"><span class="tm-white">Beauty care</span></h2>
                                        <p class="tm-text"><span class="tm-white">Good skin care is important for the following reasons: It helps your skin stay in good condition: You're shedding skin cells throughout the day, so it's important to keep your skin glowing and in good condition. An effective routine can help prevent acne, treat wrinkles, and help keep your skin looking its best.</span>
                                        </p>                                     
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                        <img src="https://post.healthline.com/wp-content/uploads/2020/09/10274-SEO_Oatmeal_Baths_A_Skin-Soothing_Home_Remedy_1200x628-facebook-1200x628.jpg" alt="Image" class="img-fluid tm-img">
                                            
                                            <figcaption>
                                                <h2 class="tm-figure-title">Oats<span>usage</span></h2>
                                                <p class="tm-figure-description">Ground oatmeal can work as an exfoliant, sloughing away dirt, oil, and dead skin cells. It can moisturize, and reduce inflammation, meaning people often use it as a home remedy for dry, itchy, or irritated skin. Doctors typically recommend that people use colloidal oatmeal for their skin.</p>
                                                <a href="img/tm-img-11.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://static-bebeautiful-in.unileverservices.com/7-DIY-rose-face-packs-for-glowing-skin_mobilehome.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Rose <span>petals</span></h2>
                                                <p class="tm-figure-description">Crush rose petals till it forms a paste. Keep it aside.
Take a tbsp. of organic honey and warm it up till it becomes runny.
Now, to the rose petals paste, add the honey, one tbsp. yogurt and two tbsp. rose water. Mix, mix, mix, and ta-da! Your face pack is ready.it has anti skin-inflammatory properties</p>
                                                <a href="img/tm-img-12.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://www.garnier.in/-/media/project/loreal/brand-sites/garnier/apac/in/all-article-pages/skin-care-tips/beauty-benefits-of-orange-for-skin/banner-3.jpg?rev=e8adde06d1d44c25b196719849c6a2d6&h=496&w=890&la=en-IN&hash=9C1105863704BE8670431DEDAD37A92F" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Orange <span>Fruit</span></h2>
                                                <p class="tm-figure-description">Orange peel is best used in a powder form. And for that you first need to dry the peel under the sun and powder it. You can store this in an air tight container for the next 6 months and use it to make fresh face packs. Combine it with other base ingredients for fresh, younger looking, clear skin.</p>
                                                <a href="img/tm-img-13.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://media.suara.com/pictures/970x544/2019/09/18/22239-tea-tree-oil.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Tea Tree<span>serum</span></h2>
                                                <p class="tm-figure-description">Tea tree oil is a popular choice for treating acne because of its anti-inflammatory and antimicrobial properties. It's thought to calm redness, swelling, and inflammation. It may even help to prevent and reduce acne scars, leaving you with smooth, clear skin.</p>
                                                <a href="img/tm-img-14.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://ecolivingmama.com/wp-content/uploads/2021/12/How-To-Make-Rice-Water-For-Hair-e1640872795468.jpg" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title">Rice<span>water</span></h2>
                                                <p class="tm-figure-description">Soaking a cotton ball in fermented rice water and gently wiping your face with it will help you deep cleanse the skin pores, further reducing the size of skin pores and leaving radiant skin. The benefits of aloe vera gel for faceare never-ending.it acts as skin exfoliator and helps to deal with dark circles and puffiness of eyes.</p>
                                                <a href="img/tm-img-15.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>
                                    <div class="grid-item">
                                        <figure class="effect-ruby">
                                            <img src="https://c.ndtvimg.com/2022-04/u19k8v6o_skincare650_625x300_05_April_22.jpg" alt="Image" class="img-fluid tm-img">
                                            <figcaption>
                                                <h2 class="tm-figure-title"> aloevera<span>jel</span></h2>
                                                <p class="tm-figure-description">take some aloe vera on your fingertips and gently apply it all over your face in circular motions.the benefits of aloe vera gel are never ending.it acts as skin exfoliator and helps to deal with the dark circles and puffiness of the eyes</p>
                                                <a href="img/tm-img-16.jpg">View more</a>
                                            </figcaption>           
                                        </figure>
                                    </div>                                                                                                 
                                </div>                                 
                            </div> <!-- .tm-img-gallery-container -->
                        </div>         
                    </div>  
                </li>

                <!-- Page 5 About -->
                <li>
                    <div class="cd-full-width">
                        <div class="container-fluid js-tm-page-content tm-page-width" data-page-no="5">
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="tm-flex">
                                        <div class="tm-bg-white-translucent text-xs-left tm-textbox tm-textbox-padding tm-white-box-margin-b">
                                            <h2 class="tm-text-title">How to choose face wash for dry skin</h2>
                                            <p class="tm-text">If you have dry skin, your face wash should be a gentle cleanser with moisturising ingredients and fatty acids in the form of oil. Dr Sharad suggests looking for ingredients such as petrolatum, lanolin and mineral oil. “This will clean the skin and leave a thin film of moisture on it,” she adds. Look for a cleanser that is hypoallergenic,It's also important to avoid antibacterial soaps and cleansers with exfoliators such as salicylic or glycolic acid, which can all dry out your skin.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="tm-flex">
                                        <div class="tm-bg-white-translucent text-xs-left tm-textbox tm-2-col-textbox-2 tm-textbox-padding">
                                            <h2 class="tm-text-title">How to choose face wash for oily skin</h2>
                                            <p class="tm-text">The ideal face wash for someone with oily skin should include ingredients like aloe vera and tea tree oil, which are both mild ingredients that balance oil production and support clarity of the skin. Remember, it shouldn't leave your skin feeling dry and tight afterwards. “Avoid cleansers that contain oil or alcohol in the ingredients, which will only amplify your oily skin type,” If you have acne prone skin, wash your face twice a day with a salicylic acid-based cleanser. Salicylic acid unclogs the pores and gets rid of excess oil.</p>
                                        </div>
                                        <div class="tm-bg-white-translucent text-xs-left tm-textbox tm-2-col-textbox-2 tm-textbox-padding">
                                            <h2 class="tm-text-title">Face wash for combination skin</h2>
                                            <p class="tm-text"> Both sensitive skin and combination skin benefit from an ultra-gentle cleanser. Look for a face wash that is fragrance-free, hypoallergenic, paraben-free and soap free, that won't irritate your skin. “Micellar waters are the best for this skin type,”.</p>     
                                        </div>
                                    </div>
                                </div>
                            </div>                        
                        </div>              
                    </div> <!-- .cd-full-width -->

                </li>

                <!-- Page 6 Contact Us -->
                <li>
                    <div class="cd-full-width">
                        <div class="container-fluid js-tm-page-content tm-page-pad" data-page-no="6">
                            <div class="tm-contact-page">                                
                                <div class="row">
                                    <div class="col-xs-12">
                                        <div class="tm-flex tm-contact-container">                                
                                            <div class="tm-bg-white-translucent text-xs-left tm-textbox tm-2-col-textbox-2 tm-textbox-padding tm-textbox-padding-contact">
                                                <h2 class="tm-contact-info">Contact Us</h2>
                                                <p class="tm-text">Feel free to contact us for further queries!!</p>                                                
                                                
                                                <!-- contact form -->
                                                <form action="index.html" method="post" class="tm-contact-form">

                                                    <div class="form-group">
                                                        <input type="text" id="contact_name" name="contact_name" class="form-control" placeholder="Name"  required/>
                                                    </div>
                                        
                                                    <div class="form-group">                                                        
                                                        <input type="email" id="contact_email" name="contact_email" class="form-control" placeholder="Email"  required/>
                                                    </div>                                                        
                                                    
                                                    <div class="form-group">
                                                        <textarea id="contact_message" name="contact_message" class="form-control" rows="5" placeholder="Your message" required></textarea>
                                                    </div> 

                                                    <button type="submit" class="pull-xs-right tm-submit-btn">Send</button>  
                                                
                                                </form>  
                                            </div>

                                            <div class="tm-bg-white-translucent text-xs-left tm-textbox tm-2-col-textbox-2 tm-textbox-padding tm-textbox-padding-contact">
                                                <h2 class="tm-contact-info">123 New Street 11000, San Francisco, CA</h2>
                                                <!-- google map goes here -->
                                                <div id="google-map"></div>
                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>    

                        </div>
                        
                    </div> <!-- .cd-full-width -->
                </li>
            </ul> <!-- .cd-hero-slider -->
            
            <footer class="tm-footer">
            
                <div class="tm-social-icons-container text-xs-center">
                    <a href="#" class="tm-social-link"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="tm-social-link"><i class="fa fa-google-plus"></i></a>
                    <a href="#" class="tm-social-link"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="tm-social-link"><i class="fa fa-behance"></i></a>
                    <a href="#" class="tm-social-link"><i class="fa fa-linkedin"></i></a>
                </div>
                
                <p class="tm-copyright-text">Copyright &copy; 2016 Your Company 
                
                - Design: <a rel="nofollow" href="http://www.templatemo.com/page/1" class="tm-footer-link" target="_parent">Templatemo</a></p>

            </footer>
                    
        </div> <!-- .cd-hero -->
        

        <!-- Preloader, https://ihatetomatoes.net/create-custom-preloading-screen/ -->
        <div id="loader-wrapper">
            
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>

        </div>
        
        <!-- load JS files -->
        <script src="js/jquery-1.11.3.min.js"></script>         <!-- jQuery (https://jquery.com/download/) -->
        <script src="https://www.atlasestateagents.co.uk/javascript/tether.min.js"></script> <!-- Tether for Bootstrap (http://stackoverflow.com/questions/34567939/how-to-fix-the-error-error-bootstrap-tooltips-require-tether-http-github-h) --> 
        <script src="js/bootstrap.min.js"></script>             <!-- Bootstrap js (v4-alpha.getbootstrap.com/) -->
        <script src="js/hero-slider-main.js"></script>          <!-- Hero slider (https://codyhouse.co/gem/hero-slider/) -->
        <script src="js/jquery.magnific-popup.min.js"></script> <!-- Magnific popup (http://dimsemenov.com/plugins/magnific-popup/) -->
        
        <script>

            function adjustHeightOfPage(pageNo) {

                var offset = 80;
                var pageContentHeight = 0;

                var pageType = $('div[data-page-no="' + pageNo + '"]').data("page-type");

                if( pageType != undefined && pageType == "gallery") {
                    pageContentHeight = $(".cd-hero-slider li:nth-of-type(" + pageNo + ") .tm-img-gallery-container").height();
                }
                else {
                    pageContentHeight = $(".cd-hero-slider li:nth-of-type(" + pageNo + ") .js-tm-page-content").height();
                }

                if($(window).width() >= 992) { offset = 120; }
                else if($(window).width() < 480) { offset = 40; }
               
                // Get the page height
                var totalPageHeight = 15 + $('.cd-slider-nav').height()
                                        + pageContentHeight + offset
                                        + $('.tm-footer').height();

                // Adjust layout based on page height and window height
                if(totalPageHeight > $(window).height()) 
                {
                    $('.cd-hero-slider').addClass('small-screen');
                    $('.cd-hero-slider li:nth-of-type(' + pageNo + ')').css("min-height", totalPageHeight + "px");
                }
                else 
                {
                    $('.cd-hero-slider').removeClass('small-screen');
                    $('.cd-hero-slider li:nth-of-type(' + pageNo + ')').css("min-height", "100%");
                }
            }

            /*
                Everything is loaded including images.
            */
            $(window).load(function(){

                adjustHeightOfPage(1); // Adjust page height

                /* Gallery One pop up
                -----------------------------------------*/
                $('.gallery-one').magnificPopup({
                    delegate: 'a', // child items selector, by clicking on it popup will open
                    type: 'image',
                    gallery:{enabled:true}                
                });
				
				/* Gallery Two pop up
                -----------------------------------------*/
				$('.gallery-two').magnificPopup({
                    delegate: 'a',
                    type: 'image',
                    gallery:{enabled:true}                
                });

                /* Gallery Three pop up
                -----------------------------------------*/
                $('.gallery-three').magnificPopup({
                    delegate: 'a',
                    type: 'image',
                    gallery:{enabled:true}                
                });

                /* Collapse menu after click 
                -----------------------------------------*/
                $('#tmNavbar a').click(function(){
                    $('#tmNavbar').collapse('hide');

                    adjustHeightOfPage($(this).data("no")); // Adjust page height       
                });

                /* Browser resized 
                -----------------------------------------*/
                $( window ).resize(function() {
                    var currentPageNo = $(".cd-hero-slider li.selected .js-tm-page-content").data("page-no");
                    
                    // wait 3 seconds
                    setTimeout(function() {
                        adjustHeightOfPage( currentPageNo );
                    }, 1000);
                    
                });
        
                // Remove preloader (https://ihatetomatoes.net/create-custom-preloading-screen/)
                $('body').addClass('loaded');
                           
            });

            /* Google map
            ------------------------------------------------*/
            var map = '';
            var center;

            function initialize() {
                var mapOptions = {
                    zoom: 15,
                    center: new google.maps.LatLng(37.769725, -122.462154),
                    scrollwheel: false
                };
            
                map = new google.maps.Map(document.getElementById('google-map'),  mapOptions);

                google.maps.event.addDomListener(map, 'idle', function() {
                  calculateCenter();
                });
            
                google.maps.event.addDomListener(window, 'resize', function() {
                  map.setCenter(center);
                });
            }

            function calculateCenter() {
                center = map.getCenter();
            }

            function loadGoogleMap(){
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&' + 'callback=initialize';
                document.body.appendChild(script);
            }
        
            // DOM is ready
            $(function() {                
                loadGoogleMap(); // Google Map
            });

        </script>            

</body>
</html>